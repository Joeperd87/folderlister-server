EBAY_PROD_CLIENT_ID=JoepLitj-Test-PRD-a8e7fd92c-7a154215
EBAY_PROD_CLIENT_SECRET=PRD-8e7fd92cde1e-e513-4f1a-bdb2-f6a5
EBAY_PROD_RU_NAME=Joep_Litjens-JoepLitj-Test-P-myqin
EBAY_PROD_REDIRECT_URL=https://e5e02f00e8f0.ngrok-free.app/oauth/ebay/callback