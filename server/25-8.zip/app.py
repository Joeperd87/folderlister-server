from __future__ import annotations

import base64
import json
import time
from pathlib import Path
from typing import Dict, Any, List, Optional
from urllib.parse import quote
import secrets as pysecrets

import requests
from fastapi import FastAPI, HTTPException, Query, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from dotenv import load_dotenv
load_dotenv()  # leest .env
# =========================
# FastAPI + CORS
# =========================
APP = FastAPI(title="Joepienator server (OAuth + Taxonomy + Stores)")
APP.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # in productie beperken!
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# Paths / bestanden
# =========================

BASE = Path(__file__).parent
DATA = BASE / "data"

def _prefer(*candidates: Path) -> Path:
    for p in candidates:
        if p.exists():
            return p
    return candidates[-1]  # laatste als default
SECRETS_FILE = _prefer(DATA / "secrets.json", BASE / "secrets.json")
TOKENS_FILE  = _prefer(BASE / "tokens.json", DATA / "tokens.json")
STATE_FILE   = _prefer(DATA / "oauth_state.json", BASE / "oauth_state.json")

# =========================
# eBay hosts
# =========================
AUTH_HOST = {"PROD": "https://auth.ebay.com", "SANDBOX": "https://auth.sandbox.ebay.com"}
API_HOST  = {"PROD": "https://api.ebay.com",  "SANDBOX": "https://api.sandbox.ebay.com"}
IDENTITY_HOST = API_HOST  # zelfde hostpad voor /identity
TRADING_ENDPOINT = {
    "PROD": "https://api.ebay.com/ws/api.dll",
    "SANDBOX": "https://api.sandbox.ebay.com/ws/api.dll",
}

# =========================
# Marketplace / SiteID
# =========================
MARKETPLACE_ID = {"UK":"EBAY_GB", "NL":"EBAY_NL", "US":"EBAY_US", "DE":"EBAY_DE"}
TRADING_SITE_ID = {"UK":"3", "US":"0", "DE":"77", "NL":"146"}

# =========================
# OAuth scopes
# =========================
USER_SCOPES = [
    "https://api.ebay.com/oauth/api_scope",
    "https://api.ebay.com/oauth/api_scope/sell.account.readonly",
    "https://api.ebay.com/oauth/api_scope/sell.stores.readonly",
]
USER_SCOPE_STR = " ".join(USER_SCOPES)
APP_SCOPES     = ["https://api.ebay.com/oauth/api_scope"]
APP_SCOPE_STR  = " ".join(APP_SCOPES)

# =========================
# Helpers: JSON IO
# =========================
def _read_json(p: Path) -> Dict[str, Any]:
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _write_json(p: Path, data: Dict[str, Any]) -> None:
    p.write_text(json.dumps(data, indent=2), encoding="utf-8")

def _now() -> int:
    return int(time.time())

# =========================
# Secrets & tokens
# =========================
def _secrets(env: str) -> Dict[str, str]:
    s = _read_json(SECRETS_FILE)
    conf = s.get(env.upper()) or {}
    cid = conf.get("client_id")
    csec = conf.get("client_secret")
    runame = conf.get("ru_name")
    if not cid or not csec or not runame:
        raise HTTPException(400, f"Server not configured with eBay app credentials for {env}")
    return {"client_id": cid, "client_secret": csec, "ru_name": runame, "redirect_url": conf.get("redirect_url")}

def _tokens() -> Dict[str, Any]:
    return _read_json(TOKENS_FILE)

def _save_tokens(d: Dict[str, Any]) -> None:
    _write_json(TOKENS_FILE, d)

def _basic_header(client_id: str, client_secret: str) -> str:
    return "Basic " + base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()

# =========================
# App token (client credentials)
# =========================
def get_app_token(env: str) -> str:
    env = env.upper()
    sec = _secrets(env)
    tk = _tokens()
    key = f"app_{env}"
    cached = tk.get(key) or {}
    if cached.get("access_token") and cached.get("expires_at", 0) > _now() + 60:
        return cached["access_token"]

    url = IDENTITY_HOST[env] + "/identity/v1/oauth2/token"
    hdr = {
        "Authorization": _basic_header(sec["client_id"], sec["client_secret"]),
        "Content-Type": "application/x-www-form-urlencoded",
    }
    data = {"grant_type": "client_credentials", "scope": APP_SCOPE_STR}
    r = requests.post(url, headers=hdr, data=data, timeout=30)
    if r.status_code >= 400:
        raise HTTPException(r.status_code, f"App token failed: {r.text}")
    j = r.json()
    tk[key] = {"access_token": j["access_token"], "expires_at": _now() + int(j.get("expires_in", 7200))}
    _save_tokens(tk)
    return j["access_token"]

# =========================
# User token helpers
# =========================
def _set_user_token(env: str, access_token: str, refresh_token: Optional[str], expires_in: int) -> None:
    tk = _tokens()
    tk["user"] = {"env": env.upper(), "access_token": access_token, "refresh_token": refresh_token, "expires_at": _now() + int(expires_in)}
    _save_tokens(tk)

def _get_user() -> Dict[str, Any]:
    return _tokens().get("user") or {}

def _need_user(env: Optional[str] = None) -> Dict[str, Any]:
    u = _get_user()
    if not u.get("access_token"):
        raise HTTPException(401, "Not linked")
    if env and u.get("env") != env.upper():
        raise HTTPException(400, f"Linked in {u.get('env')} but requested {env}")
    return u

def _refresh_user_if_needed() -> None:
    u = _get_user()
    if not u or u.get("expires_at", 0) > _now() + 60:
        return
    sec = _secrets(u["env"])
    url = IDENTITY_HOST[u["env"]] + "/identity/v1/oauth2/token"
    hdr = {"Authorization": _basic_header(sec["client_id"], sec["client_secret"]), "Content-Type": "application/x-www-form-urlencoded"}
    data = {"grant_type": "refresh_token", "refresh_token": u.get("refresh_token") or ""}
    r = requests.post(url, headers=hdr, data=data, timeout=30)
    if r.status_code >= 400:
        tk = _tokens()
        tk.pop("user", None)
        _save_tokens(tk)
        raise HTTPException(r.status_code, f"Refresh failed: {r.text}")
    j = r.json()
    _set_user_token(u["env"], j["access_token"], j.get("refresh_token", u.get("refresh_token")), int(j.get("expires_in", 3600)))

# =========================
# OAuth endpoints
# =========================
def _save_state(state: str, env: str) -> None:
    st = _read_json(STATE_FILE)
    st[state] = {"env": env, "ts": _now()}
    _write_json(STATE_FILE, st)

def _pop_state(state: Optional[str]) -> Optional[str]:
    if not state:
        return None
    st = _read_json(STATE_FILE)
    rec = (st.pop(state, None) or {})
    _write_json(STATE_FILE, st)
    return rec.get("env")

@APP.get("/oauth/start")
def oauth_start(env: str = "PROD"):
    env = env.upper()
    sec = _secrets(env)
    state = pysecrets.token_urlsafe(24)
    _save_state(state, env)
    auth_url = (
        f"{AUTH_HOST[env]}/oauth2/authorize"
        f"?client_id={quote(sec['client_id'])}"
        f"&response_type=code"
        f"&redirect_uri={quote(sec['ru_name'])}"     # ruName is vereist hier
        f"&scope={quote(USER_SCOPE_STR)}"
        f"&state={quote(state)}"
    )
    return {"auth_url": auth_url}

@APP.get("/oauth/status")
def oauth_status():
    u = _get_user()
    if not u:
        return {"env": None, "connected": False, "expires_at": None, "has_refresh": False}
    return {"env": u.get("env"), "connected": True, "expires_at": u.get("expires_at"), "has_refresh": bool(u.get("refresh_token"))}

@APP.post("/oauth/refresh")
def oauth_force_refresh():
    _refresh_user_if_needed()
    return oauth_status()

def _do_oauth_callback(code: str, env_hint: Optional[str], state: Optional[str]):
    env = (_pop_state(state) or env_hint or "PROD").upper()
    sec = _secrets(env)
    url = IDENTITY_HOST[env] + "/identity/v1/oauth2/token"
    hdr = {"Authorization": _basic_header(sec["client_id"], sec["client_secret"]), "Content-Type": "application/x-www-form-urlencoded"}
    data = {"grant_type": "authorization_code", "code": code, "redirect_uri": sec["ru_name"]}
    r = requests.post(url, headers=hdr, data=data, timeout=30)
    if r.status_code >= 400:
        raise HTTPException(r.status_code, r.text)
    j = r.json()
    _set_user_token(env, j["access_token"], j.get("refresh_token"), int(j.get("expires_in", 3600)))
    return {"ok": True, "env": env}

# callback route die je als “Auth accepted URL” kunt instellen
@APP.get("/oauth/callback")
def oauth_callback(code: str = Query(...), state: Optional[str] = None, env: str = Query("PROD")):
    return JSONResponse(_do_oauth_callback(code, env, state))

# alias (sommige configs gebruiken /oauth/ebay/callback)
@APP.get("/oauth/ebay/callback")
def oauth_callback_alias(code: str = Query(...), state: Optional[str] = None, env: str = Query("PROD")):
    res = _do_oauth_callback(code, env, state)
    # handige pagina i.p.v. kale JSON
    html = "<h2>Authorization successfully completed.</h2><p>You can close this tab.</p>"
    return HTMLResponse(html, status_code=200)

# =========================
# Commerce Taxonomy
# =========================
def _commerce_get(env: str, path: str, params: Dict[str, Any]) -> requests.Response:
    tok = get_app_token(env)
    url = API_HOST[env] + path
    hdr = {"Authorization": f"Bearer {tok}", "Accept": "application/json"}
    return requests.get(url, headers=hdr, params=params, timeout=30)

@APP.get("/taxonomy/search")
def taxonomy_search(q: str = Query(..., min_length=1), site: str = Query("UK")):
    site = site.upper()
    marketplace = MARKETPLACE_ID.get(site)
    if not marketplace:
        raise HTTPException(400, f"Unknown site {site}")
    env = (_get_user().get("env") or "PROD")
    # 1) tree id
    r1 = _commerce_get(env, "/commerce/taxonomy/v1/get_default_category_tree_id", {"marketplace_id": marketplace})
    if r1.status_code >= 400:
        raise HTTPException(r1.status_code, r1.text)
    tree_id = (r1.json() or {}).get("categoryTreeId")
    if not tree_id:
        raise HTTPException(502, "No categoryTreeId")
    # 2) suggestions
    r2 = _commerce_get(env, f"/commerce/taxonomy/v1/category_tree/{tree_id}/get_category_suggestions", {"q": q})
    if r2.status_code >= 400:
        raise HTTPException(r2.status_code, r2.text)
    out: List[Dict[str, Any]] = []
    for item in (r2.json() or {}).get("categorySuggestions", []):
        cat = item.get("category") or {}
        cid  = cat.get("categoryId")
        name = cat.get("categoryName")
        path = " > ".join([p.get("categoryName") for p in item.get("categoryTreeNodeAncestors", []) if p.get("categoryName")])
        if cid and name:
            out.append({"categoryId": cid, "name": name, "path": path})
    return out

@APP.get("/taxonomy/aspects")
def taxonomy_aspects(site: str = Query("UK"), category_id: str = Query(...)):
    site = site.upper()
    marketplace = MARKETPLACE_ID.get(site)
    if not marketplace:
        raise HTTPException(400, f"Unknown site {site}")
    env = (_get_user().get("env") or "PROD")
    r1 = _commerce_get(env, "/commerce/taxonomy/v1/get_default_category_tree_id", {"marketplace_id": marketplace})
    if r1.status_code >= 400:
        raise HTTPException(r1.status_code, r1.text)
    tree_id = (r1.json() or {}).get("categoryTreeId")
    if not tree_id:
        raise HTTPException(502, "No categoryTreeId")
    r2 = _commerce_get(env, f"/commerce/taxonomy/v1/category_tree/{tree_id}/get_item_aspects_for_category", {"category_id": category_id})
    if r2.status_code >= 400:
        raise HTTPException(r2.status_code, r2.text)
    return r2.json()

# =========================
# Stores (REST + Trading fallback)
# =========================
def _rest_store_categories(env: str) -> List[Dict[str, Any]]:
    _refresh_user_if_needed()
    u = _need_user(env)
    hdr = {"Authorization": f"Bearer {u['access_token']}", "Accept": "application/json"}
    # store info
    r0 = requests.get(API_HOST[env] + "/sell/stores/v1/store", headers=hdr, timeout=30)
    if r0.status_code >= 400:
        raise HTTPException(r0.status_code, r0.text)
    sid = (r0.json() or {}).get("storeId")
    if not sid:
        return []
    r1 = requests.get(API_HOST[env] + f"/sell/stores/v1/store/{sid}/categories", headers=hdr, timeout=30)
    if r1.status_code >= 400:
        raise HTTPException(r1.status_code, r1.text)
    cats: List[Dict[str, Any]] = []
    for c in (r1.json() or {}).get("categories", []):
        cats.append({
            "id": str(c.get("categoryId")),
            "name": c.get("name"),
            "parent_id": str(c.get("parentCategoryId")) if c.get("parentCategoryId") not in (None, "") else None
        })
    return cats

def _trading_getstore(env: str, site: str) -> List[Dict[str, Any]]:
    _refresh_user_if_needed()
    u = _need_user(env)
    site_id = TRADING_SITE_ID.get(site.upper(), "0")
    xml = """<?xml version="1.0" encoding="utf-8"?>
<GetStoreRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <CategoryStructureOnly>true</CategoryStructureOnly>
</GetStoreRequest>""".strip()
    headers = {
        "X-EBAY-API-CALL-NAME": "GetStore",
        "X-EBAY-API-SITEID": site_id,
        "X-EBAY-API-COMPATIBILITY-LEVEL": "1193",
        "X-EBAY-API-IAF-TOKEN": u["access_token"],
        "X-EBAY-API-REQUEST-ENCODING": "XML",
        "Content-Type": "text/xml",
        "Accept": "text/xml",
    }
    r = requests.post(TRADING_ENDPOINT[env], headers=headers, data=xml.encode("utf-8"), timeout=30)
    if r.status_code >= 400:
        raise HTTPException(r.status_code, r.text)
    # eenvoudige XML parse
    from xml.etree import ElementTree as ET
    try:
        root = ET.fromstring(r.text)
    except ET.ParseError as e:
        raise HTTPException(502, f"Parse error: {e}\n{r.text}")
    ns = {"e": "urn:ebay:apis:eBLBaseComponents"}
    out: List[Dict[str, Any]] = []
    def walk(node, parent_id: Optional[str]):
        for cat in node.findall("e:StoreCategories/e:StoreCategory", ns):
            cid  = (cat.findtext("e:CategoryID", default="", namespaces=ns) or "").strip()
            name = (cat.findtext("e:Name", default="", namespaces=ns) or "").strip()
            out.append({"id": cid, "name": name, "parent_id": parent_id})
            walk(cat, cid)
    store_root = root.find("e:Store", ns)
    if store_root is not None:
        walk(store_root, None)
    return out

@APP.get("/stores/categories")
def stores_categories(site: str = Query("UK"), prefer: str = Query("rest")):
    env = (_get_user().get("env") or "PROD").upper()
    prefer = (prefer or "rest").lower().strip()
    try:
        if prefer == "trading":
            return _trading_getstore(env, site)
        try:
            return _rest_store_categories(env)
        except HTTPException:
            return _trading_getstore(env, site)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, str(e))

# =========================
# Media (placeholder)
# =========================
@APP.post("/media/upload")
def media_upload(file: UploadFile = File(...)):
    content = file.file.read()
    import hashlib
    sha1 = hashlib.sha1(content).hexdigest()
    return {"image_url": f"https://i.ebayimg.com/images/generic/{sha1}.jpg", "hash": sha1}

# =========================
# Root
# =========================
@APP.get("/")
def root():
    return {"ok": True}
