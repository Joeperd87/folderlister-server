from __future__ import annotations
from pathlib import Path
import time, json, hmac, hashlib, os
from datetime import datetime, timezone
from typing import Optional, Dict, Any

BASE_DIR = Path(__file__).resolve().parent
FILE = Path(os.getenv("LICENSE_JSON_PATH") or (BASE_DIR / "data" / "licenses.json"))
SECRET = os.getenv("LICENSE_HMAC_SECRET", "CHANGE_ME_DEV_SECRET").encode("utf-8")
_CACHE_TTL = float(os.getenv("LICENSE_CACHE_TTL", "10"))

_cache: Dict[str, Any] = {}
_cache_mtime: float = 0.0
_cache_loaded_at: float = 0.0

def _hmac_key(plain: str) -> str:
    digest = hmac.new(SECRET, plain.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"HMAC256:{digest}"

def fingerprint(plain: str) -> str:
    return _hmac_key(plain)[8:18]

def _load_if_stale():
    global _cache, _cache_mtime, _cache_loaded_at
    try:
        mtime = FILE.stat().st_mtime
    except FileNotFoundError:
        _cache, _cache_mtime = {}, 0.0
        return
    now = time.time()
    if (now - _cache_loaded_at) > _CACHE_TTL or mtime != _cache_mtime:
        _cache = json.loads(FILE.read_text("utf-8") or "{}")
        _cache_mtime = mtime
        _cache_loaded_at = now

def find_license(plain_key: str) -> Optional[Dict[str, Any]]:
    if not plain_key:
        return None
    _load_if_stale()
    return _cache.get(_hmac_key(plain_key))

def is_valid(rec: Dict[str, Any]) -> bool:
    if not rec or rec.get("status") != "active":
        return False
    exp_s = rec.get("expires_at")
    if not exp_s:
        return False
    try:
        if exp_s.endswith("Z"):
            exp = datetime.fromisoformat(exp_s.replace("Z", "+00:00"))
        else:
            exp = datetime.fromisoformat(exp_s)
    except Exception:
        return False
    return exp > datetime.now(timezone.utc)

def upsert_license_plain(plain_key: str, plan: str, expires_at_iso_utc: str, status: str = "active", **extra):
    FILE.parent.mkdir(parents=True, exist_ok=True)
    data = {}
    if FILE.exists():
        txt = FILE.read_text("utf-8").strip()
        if txt:
            data = json.loads(txt)
    h = _hmac_key(plain_key)
    rec = {
        "plan": plan,
        "expires_at": expires_at_iso_utc,
        "status": status,
        "created_at": extra.get("created_at"),
        "last_seen_at": extra.get("last_seen_at"),
        "max_accounts": int(extra.get("max_accounts") or 1),
        "owner_email": extra.get("owner_email"),
        "owner_name": extra.get("owner_name"),
        "allowed_ebay_users": extra.get("allowed_ebay_users") or None,
        "notes": extra.get("notes"),
    }
    rec = {k: v for k, v in rec.items() if v is not None}
    data[h] = rec
    tmp = FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(FILE)

def attach_ebay_user(plain_key: str, ebay_user: str, max_accounts_default: int = 1) -> dict:
    data = {}
    if FILE.exists():
        txt = FILE.read_text("utf-8").strip()
        if txt:
            data = json.loads(txt)
    h = _hmac_key(plain_key)
    rec = data.get(h)
    if not rec:
        raise ValueError("License not found")
    if rec.get("status") != "active":
        raise ValueError("License not active")
    slots = int(rec.get("max_accounts") or max_accounts_default or 1)
    lst = rec.get("allowed_ebay_users") or []
    if ebay_user in lst:
        pass
    else:
        if len(lst) >= slots:
            raise ValueError("Max accounts reached")
        lst.append(ebay_user)
        rec["allowed_ebay_users"] = lst
    data[h] = rec
    tmp = FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(FILE)
    return rec
